var saludo = "Hola Coders!";
var numeroA = 5;
var numeroB = 15;

var nombre = prompt("Ingrese su nombre:")

var apellido = prompt("Ingrese su apellido:")

var resultado = alert(nombre + apellido);

var edad = prompt("Ingrese su edad")

var edad = parseInt(edad)

alert(edad + numeroA)

console.log("Camada 8695")

console.info("otro texto")

console.warn("warning")

console.error("esto es un error")
