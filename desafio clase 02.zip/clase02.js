// DESAFIO 

// 1

var numero = parseInt(prompt('ingrese un numero'))

if(numero > 1000) {
    alert('el numero ingresado es mayor a mil' ) 
}
else { alert('el numero ingresado es menor a mil' )
}

// 2

var saludo = prompt('ingrese un saludo')

if(saludo == 'Hola') {
    console.warn('el saludo ingresado es Hola' ) 
}

// 3

var numero = prompt('ingrese un numero')

var numero = parseInt(numero)

if(numero > 10 && numero < 50 ) {
    alert('el numero ingresado esta entre 10 y 50' ) 
}
else {
    alert('el numero ingresado NO esta entre 10 y 50' )
}

